This is a modified version of the unarr decompression library which removes support for compression formats other than rar. The original unarr source is available at 

https://github.com/selmf/unarr

Unarr uses an LPGL license. See the accompanying COPYING document for the license terms.