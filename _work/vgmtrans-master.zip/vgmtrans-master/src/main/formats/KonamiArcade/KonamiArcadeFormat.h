#pragma once
#include "Format.h"
#include "KonamiArcadeScanner.h"

BEGIN_FORMAT(KonamiArcade)
  USING_SCANNER(KonamiArcadeScanner)
END_FORMAT()
