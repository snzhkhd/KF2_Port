#include <spdlog/fmt/fmt.h>
#include "CPS1Instr.h"
#include "CPS2Format.h"
#include "VGMRgn.h"
#include "OkiAdpcm.h"
#include "version.h"

// ******************
// CPS1SampleInstrSet
// ******************

CPS1SampleInstrSet::CPS1SampleInstrSet(RawFile *file,
                                       CPS1FormatVer version,
                                       uint32_t offset,
                                       std::string name)
    : VGMInstrSet(CPS1Format::name, file, offset, 0, std::move(name)),
      fmt_version(version) {
}

bool CPS1SampleInstrSet::parseInstrPointers() {
  switch (fmt_version) {
    case CPS1_V100:
    case CPS1_V200:
    case CPS1_V350:
    case CPS1_V500:
    case CPS1_V502:
      for (int i = 1; i < 128; ++i) {
        std::string name = fmt::format("Instrument {:03d}", i);
        VGMInstr* instr = new VGMInstr(this, 0, 0, 0, i, name, 0);
        VGMRgn* rgn = new VGMRgn(instr, 0);
        rgn->sampNum = i - 1;
        rgn->release_time = 10;
        instr->addRgn(rgn);
        aInstrs.push_back(instr);
      }
      break;

    case CPS1_V425:
      for (int i = 0; i < 128; ++i) {
        auto instrOff = offset() + (i * 4);
        if (!(readByte(instrOff) & 0x80)) {
          break;
        }
        std::string name = fmt::format("Instrument {}", i);
        VGMInstr* instr = new VGMInstr(this, instrOff, 4, 0, i, name, 0);
        VGMRgn* rgn = new VGMRgn(instr, instrOff);
        instr->setLength(4);
        rgn->setLength(4);
        // subtract 1 to account for the first OKIM6295 sample ptr always being null
        rgn->sampNum = readByte(instrOff+1) - 1;
        rgn->release_time = 10;
        instr->addRgn(rgn);
        aInstrs.push_back(instr);
      }
      break;
  }
  return true;
}

// **************
// CPS1SampColl
// **************

CPS1SampColl::CPS1SampColl(RawFile *file,
                           CPS1SampleInstrSet *theinstrset,
                           uint32_t offset,
                           uint32_t length,
                           std::string name)
    : VGMSampColl(CPS1Format::name, file, offset, length, std::move(name)),
      instrset(theinstrset) {
}


bool CPS1SampColl::parseHeader() {
  auto header = addHeader(8, 0x400-8, "Sample Pointers");

  int i = 1;
  for (int offset = 8; offset < 0x400; offset += 8) {
    if (readWord(offset) == 0xFFFFFFFF) {
      break;
    }
    auto startStr = fmt::format("Sample {} Start", i);
    auto endStr = fmt::format("Sample {} End", i);
    i += 1;

    header->addChild(offset, 3, startStr);
    header->addChild(offset+3, 3, endStr);
  }
  return true;
}

bool CPS1SampColl::parseSampleInfo() {
  constexpr int PTR_SIZE = 3;

  int i = 1;
  for (int offset = 8; offset < 0x400; offset += 8) {
    auto sampAddr = readShort(offset);

    VGMSamp* sample;
    if (sampAddr == 0xFFFF || sampAddr == 0) {
      auto name = fmt::format("Empty Sample {:03d}", i);
      sample = new EmptySamp(this);
    } else {
      auto name = fmt::format("Sample {:03d}", i);
      auto begin = readWordBE(offset) >> 8;
      auto end = readWordBE(offset+PTR_SIZE) >> 8;
      sample = new DialogicAdpcmSamp(this, begin, end > begin ? end-begin : 0, CPS1_OKIMSM6295_SAMPLE_RATE, CPS1_OKI_GAIN, name);
    }
    i += 1;
    sample->setBPS(BPS::PCM16);
    sample->setLoopStatus(false);
    sample->unityKey = 0x3C;
    samples.push_back(sample);
  }
  return true;
}

// ***************
// CPS1OPMInstrSet
// ***************

CPS1OPMInstrSet::CPS1OPMInstrSet(RawFile *file,
                               CPS1FormatVer version,
                               u8 masterVol,
                               u32 offset,
                               u32 length,
                               const std::string& name)
    : YM2151InstrSet(CPS1Format::name, file, offset, length, name),
      fmt_version(version), masterVol(masterVol) {
}

bool CPS1OPMInstrSet::parseInstrPointers() {
  int numInstrs;
  size_t instrSize;
  switch (fmt_version) {
    case CPS1_V200:
      instrSize = sizeof(CPS1OPMInstrDataV2_00);
      break;
    case CPS1_V500:
    case CPS1_V502:
      instrSize = sizeof(CPS1OPMInstrDataV5_02);
      break;
    case CPS1_V100:
    case CPS1_V350:
    case CPS1_V425:
      instrSize = sizeof(CPS1OPMInstrDataV4_25);
      break;
  }
  numInstrs = std::min(length() / static_cast<u32>(instrSize), 128U);

  for (int i = 0; i < numInstrs; ++i) {
    auto instrOff = offset() + (i * instrSize);
    if (readWord(instrOff) == 0 && readWord(instrOff+4) == 0) {
      break;
    }

    auto name = fmt::format("Instrument {}", i);

    switch (fmt_version) {
      case CPS1_V200: {
        CPS1OPMInstrDataV2_00 instrData{};
        readBytes(instrOff, static_cast<uint32_t>(instrSize), &instrData);
        auto instr = new CPS1OPMInstr<CPS1OPMInstrDataV2_00>(this, masterVol, instrOff, instrSize, 0, i, name);
        aInstrs.push_back(instr);
        addOPMInstrument(instrData.convertToOPMData(masterVol, name));
        break;
      }
      case CPS1_V500:
      case CPS1_V502: {
        CPS1OPMInstrDataV5_02 instrData{};
        readBytes(instrOff, static_cast<uint32_t>(instrSize), &instrData);
        auto instr = new CPS1OPMInstr<CPS1OPMInstrDataV5_02>(this, masterVol, instrOff, instrSize, 0, i, name);
        aInstrs.push_back(instr);
        addOPMInstrument(instrData.convertToOPMData(masterVol, name));
        break;
      }
      case CPS1_V100:
      case CPS1_V350:
      case CPS1_V425: {
        CPS1OPMInstrDataV4_25 instrData{};
        readBytes(instrOff, static_cast<uint32_t>(instrSize), &instrData);
        auto instr = new CPS1OPMInstr<CPS1OPMInstrDataV4_25>(this, masterVol, instrOff, instrSize, 0, i, name);
        aInstrs.push_back(instr);
        std::vector<uint8_t> driverData;
        uint8_t enableLfo = instrData.LFO_ENABLE_AND_WF >> 7;
        uint8_t resetLfo = (instrData.LFO_ENABLE_AND_WF >> 1) & 1;
        driverData.push_back(enableLfo);
        driverData.push_back(resetLfo);
        for (int i = 0; i < 4; i ++) {
          driverData.push_back(instrData.volData[i].key_scale);
          driverData.push_back(instrData.volData[i].extra_atten);
        }

        addOPMInstrument(instrData.convertToOPMData(masterVol, name), "cps", std::move(driverData));
        instr->addChild(new VGMItem(this, instrOff, 1, "Transpose"));
        instr->addChild(new VGMItem(this, instrOff+1, 1, "LFO_ENABLE_AND_WF"));
        instr->addChild(new VGMItem(this, instrOff+2, 1, "LFRQ"));
        instr->addChild(new VGMItem(this, instrOff+3, 1, "PMD"));
        instr->addChild(new VGMItem(this, instrOff+4, 1, "AMD"));
        instr->addChild(new VGMItem(this, instrOff+5, 1, "FL_CON"));
        instr->addChild(new VGMItem(this, instrOff+6, 1, "PMS_AMS"));
        instr->addChild(new VGMItem(this, instrOff+7, 1, "SLOT_MASK"));
        instr->addChild(new VGMItem(this, instrOff+8, 12, "Driver-specific Volume Params"));
        instr->addChild(new VGMItem(this, instrOff+20, 4, "DT1_MUL"));
        instr->addChild(new VGMItem(this, instrOff+24, 4, "KS_AR"));
        instr->addChild(new VGMItem(this, instrOff+28, 4, "AMSEN_D1R"));
        instr->addChild(new VGMItem(this, instrOff+32, 4, "DT2_D2R"));
        instr->addChild(new VGMItem(this, instrOff+36, 4, "D1L_RR"));
        break;
      }
    }
  }
  return true;
}
