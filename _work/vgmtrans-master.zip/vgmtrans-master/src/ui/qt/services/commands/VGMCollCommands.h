/*
 * VGMTrans (c) 2002-2025
 * Licensed under the zlib license,
 * refer to the included LICENSE.txt file
 */

#pragma once

#include "GeneralCommands.h"
#include "SequencePlayer.h"
#include "services/commands/Command.h"
#include "VGMColl.h"

using MenuPath = Command::MenuPath;

/**
 * A command for playing or pausing a collection with the SequencePlayer
 */
class PlayCommand : public SingleItemCommand<VGMColl> {
public:
  void executeItem(VGMColl* coll) const override {
    SequencePlayer::the().playCollection(coll);
  }
  [[nodiscard]] QList<QKeySequence> shortcutKeySequences() const override { return {Qt::Key_Return}; };
  [[nodiscard]] std::string name() const override { return "Play / Pause"; }
  [[nodiscard]] std::optional<MenuPath> menuPath() const override { return MenuPaths::Preview; }
};
